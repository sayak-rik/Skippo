export const dashboardModules = [
  {
    href: "/dashboard/live-fleet",
    title: "Live Fleet",
    subtitle: "Open any active trip, track every bus, and review route status.",
    badge: "Transport",
  },
  {
    href: "/dashboard/students",
    title: "Students",
    subtitle: "Browse students, linked parents, classes, and transport assignments.",
    badge: "Core Data",
  },
  {
    href: "/dashboard/teachers",
    title: "Teachers",
    subtitle: "Review schedules, attendance velocity, and parent-facing comment activity.",
    badge: "Academics",
  },
  {
    href: "/dashboard/drivers",
    title: "Drivers",
    subtitle: "Manage OTP sessions, trip activity, assigned vehicles, and SOS history.",
    badge: "Operations",
  },
  {
    href: "/dashboard/routes",
    title: "Routes",
    subtitle: "Manage route definitions, stops, vehicle allocation, and timing logic.",
    badge: "Transport",
  },
  {
    href: "/dashboard/communications",
    title: "Communications",
    subtitle: "Send notices, parent updates, partner campaigns, and operational broadcasts.",
    badge: "Parent Feed",
  },
  {
    href: "/dashboard/compliance",
    title: "Compliance",
    subtitle: "Track NOC, insurance, permits, pollution, fitness, and renewal deadlines.",
    badge: "Risk",
  },
  {
    href: "/dashboard/reports",
    title: "Reports",
    subtitle: "Review attendance, unread teacher comments, trip activity, and daily summaries.",
    badge: "Insight",
  },
  {
    href: "/dashboard/settings",
    title: "Settings",
    subtitle: "Configure school identity, dashboard URL, branding, and admin preferences.",
    badge: "Admin",
  },
] as const;
